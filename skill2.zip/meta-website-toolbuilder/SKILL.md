---
name: meta-website-toolbuilder
description: >
  Meta-skill that generates a complete, project-specific suite of Claude agents, slash commands,
  design system, templates, and CLAUDE.md for any new React + Vite + Netlify contractor/service
  business website. Produces better tooling than generic boilerplate by tailoring every tool to the
  specific business, niche, design aesthetic, and project requirements. This skill should be used
  when starting a new client website project and the user wants to generate the full development
  toolkit (agents, commands, config, design system) in one shot.
---

# Meta Website Toolbuilder

Generate a complete, project-specific development toolkit for React + Vite + Netlify service business websites. Produce tailored agents, commands, design system, configuration, and CLAUDE.md that outperform generic boilerplate by being tuned to the exact business, niche, aesthetic, and scope.

## When to Use

Trigger when:
- Starting a new client website project and generating the full toolkit
- The user says "build tools for [project]", "set up a new project", or "generate toolkit for [business]"
- Rebuilding or upgrading an existing project's tooling
- The user wants project-specific agents/commands rather than generic ones

## Workflow Overview

The toolbuilder runs in 3 phases:

1. **Discovery** -- Gather project requirements via structured intake
2. **Generation** -- Produce all files tailored to the specific project
3. **Validation** -- Verify the generated toolkit is complete and internally consistent

---

## Phase 1: Discovery

Before generating anything, gather the following information. Ask the user for anything not already known. Group questions to avoid overwhelming -- start with business basics, then design, then scope.

### Required Intake

**Business Profile:**
- Business name, tagline/slogan
- Industry/niche (masonry, roofing, plumbing, HVAC, electrical, painting, fencing, concrete, landscaping, general contracting, etc.)
- Location (city, state, zip)
- Phone, email, physical address
- Services offered (list with brief descriptions)
- Service area (cities/counties served)
- Years in business, certifications, BBB rating, license numbers
- Google Business Profile URL
- Social media URLs (Facebook, Instagram, etc.)
- Competitive differentiators (what makes them stand out)

**Project Scope:**
- Pages needed (default: Home, Projects/Gallery, Contact, Privacy)
- Additional pages (About, Services detail, Testimonials, Blog, FAQ, Careers)
- Contact form fields needed
- Project photos available (count, quality, subjects)
- Testimonials available (count, with attribution)
- Domain name (owned or to be purchased)
- GitHub repo URL (or create new)
- Netlify site name
- Google Analytics measurement ID (or set up new)
- Timeline and budget context

**Design Direction:**
- Mood/aesthetic (e.g., "rustic warmth", "modern minimal", "bold industrial", "classic elegance")
- Color preferences (primary, accent) or "generate from niche"
- Competitor sites to reference or differentiate from
- Logo available (format, colors)
- Photo style (professional shoots, jobsite photos, drone shots)

### Niche-Specific Defaults

When the user provides only the business niche, apply intelligent defaults from `references/design-systems.md` to pre-fill design tokens, SEO keywords, schema types, and content structures. Present these defaults for confirmation before proceeding.

---

## Phase 2: Generation

Generate the complete toolkit into the project directory. Every generated file must be specific to THIS project -- no `[PLACEHOLDER]` text, no `TODO` markers, no generic content. Fill everything from Discovery intake.

### Output Structure

```
project-root/
  .claude/
    agents/
      qa-tester.md              -- 12-category QA (expanded from 10)
      deploy-validator.md       -- 40-point deploy checklist (expanded from 32)
      seo-auditor.md            -- Local SEO + schema + competitor gap analysis
      client-docs-writer.md     -- 4 handover docs + maintenance proposal
      design-system-builder.md  -- Generate/refine CSS design system
      performance-optimizer.md  -- Core Web Vitals + Lighthouse optimization
      content-writer.md         -- Niche-specific copy generation
      accessibility-auditor.md  -- WCAG 2.1 AA deep audit
    commands/
      qa.md                     -- Full QA with expanded categories
      deploy.md                 -- Validate + deploy + post-deploy smoke test
      handover.md               -- Generate all client deliverables
      new-page.md               -- Scaffold page matching project patterns
      review.md                 -- Code review with project-specific rules
      seo-check.md              -- SEO audit + auto-fix + schema generation
      perf.md                   -- Performance audit + optimization
      design-system.md          -- Generate or update design system
      content.md                -- Generate page copy from brief
      a11y.md                   -- Accessibility audit
  CLAUDE.md                     -- Fully populated project instructions
  netlify.toml                  -- Production-ready Netlify config
  public/
    _redirects                  -- SPA fallback
    robots.txt                  -- Search engine directives
    sitemap.xml                 -- URL sitemap with all routes
  templates/
    client-emails/
      1-project-kickoff.md
      2-design-review.md
      3-launch-day.md
      4-post-launch-followup.md
    QA-CHECKLIST.md
    VALUE-DELIVERABLES.md
```

### Generation Order

Generate files in this order (later files depend on earlier ones):

1. **CLAUDE.md** -- Use `assets/claude-md-template.md` as skeleton. Fill every field from intake. This becomes the source of truth for all other generators.

2. **Design System** -- Use `references/design-systems.md` to select or generate a design system based on the niche and aesthetic direction. Output a complete CSS custom properties block with:
   - Color palette (8-12 tokens: bg-deep, bg-base, surface, primary, primary-light, primary-pale, accent, text-primary, text-secondary, text-muted, success, error)
   - Typography stack (display font, body font, mono font -- selected from niche-appropriate Google Fonts pairings)
   - Spacing scale, border radii, transitions, shadows
   - Component token mappings (button colors, form colors, card colors)
   Write the design system section directly into CLAUDE.md under "Design System".

3. **Netlify Configuration** -- Generate `netlify.toml`, `public/_redirects`, `public/robots.txt`, `public/sitemap.xml` using the domain, routes, and form names from intake.

4. **Agents** -- Generate each agent from `references/agent-blueprints.md`, customizing:
   - Business name, domain, niche-specific checks
   - SEO keywords and schema type for the specific industry
   - Form field names matching the project's actual contact form
   - Image directory paths and naming conventions
   - Design system token names for consistency checks

5. **Commands** -- Generate each command from `references/command-blueprints.md`, wiring them to the correct agent names and project paths.

6. **Templates** -- Generate email templates and checklists with business name, domain, developer contact, and niche-specific content pre-filled.

---

## Phase 3: Validation

After generation, verify:

1. **Internal consistency** -- Every file reference in CLAUDE.md points to a real generated file. Every agent referenced by a command exists. Every route in sitemap.xml matches CLAUDE.md route table.
2. **No placeholders** -- Grep all generated files for `[`, `TODO`, `FIXME`, `PLACEHOLDER`, `YOUR`, `EXAMPLE`. Flag any found.
3. **Completeness** -- Every file in the Output Structure exists and has substantive content (not just headers).
4. **Design system coherence** -- CSS tokens referenced in agent instructions match the actual design system tokens in CLAUDE.md.

Report results to the user with a checklist. If issues found, fix automatically and re-validate.

---

## What Makes This Better Than Generic Boilerplate

The existing `_project-toolkit` is a fill-in-the-blanks template. This skill generates a fully realized, project-specific toolkit.

### More Agents (8 vs 4)
- **design-system-builder** -- Generates and maintains a cohesive CSS design system. Audits for token consistency, unused variables, color contrast ratios, and responsive scaling. Can regenerate the system if the aesthetic direction changes.
- **performance-optimizer** -- Runs Lighthouse-style checks: image sizing, lazy loading, font loading strategy, CSS/JS bundle analysis, render-blocking resources, CLS/LCP/FID targets. Produces specific optimization commands.
- **content-writer** -- Generates niche-specific website copy: hero headlines, service descriptions, about sections, CTAs, meta descriptions, alt text. Uses industry terminology and local SEO keywords naturally.
- **accessibility-auditor** -- Goes beyond basic alt-text checks: color contrast ratios against WCAG 2.1 AA, keyboard navigation flow, screen reader landmark structure, focus management, ARIA pattern correctness, motion/animation preferences.

### More Commands (10 vs 6)
- **/perf** -- Performance audit targeting Core Web Vitals thresholds
- **/design-system** -- Generate or regenerate the CSS design system
- **/content [page] [section]** -- Generate copy for a specific page section
- **/a11y** -- Deep accessibility audit with WCAG 2.1 AA compliance check

### Deeper Customization
- **Niche-aware SEO**: Schema type matches the exact business (MasonryContractor vs PlumbingBusiness vs RoofingContractor). Keywords are industry-specific, not generic.
- **Design system from niche**: A masonry business gets warm stone tones and serif fonts. A modern HVAC company gets cool blues and clean sans-serif. An electrician gets high-contrast yellows and industrial fonts.
- **Content that sounds right**: Generated copy uses industry terminology (e.g., "tuckpointing" and "veneer" for masonry, not generic "quality service").
- **Form fields match the niche**: A roofer's contact form has "Roof Type" and "Storm Damage?" fields. A mason's has "Project Type" and "Stone Preference."

### Zero Placeholders
Every generated file is immediately usable. No `[FILL IN]` markers. The toolkit is ready to drive development from the moment it is created.

---

## Reference Files

- `references/agent-blueprints.md` -- Complete templates for all 8 agents with customization points marked
- `references/command-blueprints.md` -- Complete templates for all 10 commands with wiring instructions
- `references/design-systems.md` -- Niche-to-design-system mapping with color palettes, typography, and aesthetic profiles for 15+ contractor niches

## Asset Files

- `assets/claude-md-template.md` -- CLAUDE.md skeleton with every section pre-structured
- `assets/netlify.toml` -- Production Netlify config template
- `assets/_redirects` -- SPA redirect rule
- `assets/robots.txt` -- Robots template with sitemap reference
- `assets/sitemap-template.xml` -- Sitemap skeleton with route placeholders
- `assets/client-emails/` -- 4 email templates with merge fields
